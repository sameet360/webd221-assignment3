<!-- CONTACT CONTENT -->
    

    
    <div class="contactHeader">
        <h4>LET'S DISCUSS</h4>
        <div class="heartDivider">
                <ul class="heartDeco">
                    <li><div class="heartDecor"></div></li>
                    <li><i class="fa fa-heart-o"></i></li>
                    <li><div class="heartDecor"></div></li>
                </ul>
            </div>
        <p>Voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore</p>
    </div> <!-- END OF CONTACT HEADER -->
    <div class="contactContent">
        <aside> <!-- FLOAT LEFT -->
            <p class="large">Cras at ultrices erat, sed vulputate!</h7>
            <p>2345 Setwant natrer, 1234, <br>
            Washington. United States. <br>
            (401) 1234 567 <br>
            hello@brandi.com <br>
            ww.brandi.com</p>
        </aside>
            
        <form method="post" action="submit-form.php">
            
            <h6>Say hello!</h6>
            
            <input type="text" placeholder="Name" name="name" id="name">

            <input type="text" placeholder="Email" name="email" id="email"> <br>

            <input type="text" placeholder="Message" name="message" id="message"><br>
            
            <div id="submit">
                <i class="fa fa-envelope-o"></i>
                <input type="submit" name="submit" value="Send Message">
            </div>
        </form>
             
        <div class="SecondSocial">
            <ul class="icons">
                <li><a href="behance.com"><div class="fa fa-behance"></div></a></li>
                <li><a href="twitter.com"><div class="fa fa-twitter"></div></a></li>
                <li><a href="dribbble.com"><div class="fa fa-dribbble"></div></a></li>
                <li><a href="github.com"><div class="fa fa-github"></div></a></li>                    
                <li><a href="google.com"><div class="fa fa-google-plus"></div></a></li>
            </ul>
        </div> 
    </div>
<!-- CONTACT CONTENT -->