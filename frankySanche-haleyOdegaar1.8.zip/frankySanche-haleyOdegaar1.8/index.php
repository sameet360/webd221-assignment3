<!DOCTYPE html> 
<html>
<head>
	<title>Brandi!</title>
	<link rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="responsive.css">
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:700,300,400' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Pacifico' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/font-awesome-4.2.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="css/normalize.css">
	<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
	<script src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
	<script src="http://unslider.com/unslider.min.js"></script>

	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
</head>


<body>
	
		<header>
			<nav>
				<div id="navWrap">
					<div id="logoTagline">
						<h1>Brandi</h1>
						<h2><span id="tagDivider">|&nbsp&nbsp&nbsp&nbsp&nbsp</span>I am your tagline</h2>
					</div>
					<ul id="dropDownMenu">
						<li><a href="#about">home</a></li>
						<li><a href="#features">features</a></li>
						<li><a href="#work">work</a></li>
						<li><a href="#team">team</a></li>
						<li><a href="#contact">contact</a></li>
					</ul>
				</div>
			</nav>
			<div id="stage1">
				<div id="greetingResize">
					<h3 align="center" id="greetingMsg">Meet&nbsp<span>Brandi</span>!</h3>
					<p class="productTitle"><span class="aquaColor">/creative</span> one page template.</p>
					<div id="jobWrap">
						<ul class="jobParts">
							<li><div class="jobDecorLeft"></div></li>
							<li><p class="jobTitle">We are a team of professionals</p></li>
							<li><div class="jobDecorRight"></div></li>
						</ul>
					</div>
					<div id="social">
						<ul>
							<li><a href="#"><i class="fa fa-twitter"></i></a></li>
							<li><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
							<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
						</ul>
					</div>
				</div>
			</div><!-- STAGE 1 -->
		</header>

		<section id="features">
			<h4 align="center">FEATURES</h4>
			
			<!-- ********************HEART DIVIDER*************** -->
			
			<div class="heartDivider">
				<ul class="heartDeco">
					<li><div class="heartDecor"></div></li>
					<li><i class="fa fa-heart-o"></i></li>
					<li><div class="heartDecor"></div></li>
				</ul>
			</div>
			<!-- ********************HEART DIVIDER*************** -->


				<div class="sliderWrap">
					<div class="featureSlider">
						<ul>
							<li>	
								<div class="featureFloat">
									<img align="left" src="assets/features_icon_1.png">
									<div class="featureTxt">
										<h5>Branding</h5>
										<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore</p>
									</div>								
								</div>
							</li>
							<li>	
								<div class="featureFloat">
									<img align="left" src="assets/features_icon_1.png">
									<div class="featureTxt">
										<h5>Development</h5>
										<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore</p>
									</div>								
								</div>
							</li>
							<li>	
								<div class="featureFloat">
									<img align="left" src="assets/features_icon_1.png">
									<div class="featureTxt">
										<h5>Consulting</h5>
										<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore</p>
									</div>								
								</div>
							</li>
						</ul>
					</div>
				</div>
		</section>



		<section id="works">
	
			</div>
			<h4 align="center">WORKS</h4>

			<!-- ********************HEART DIVIDER*************** -->
			
			<div class="heartDivider">
				<ul class="heartDeco">
					<li><div class="heartDecor"></div></li>
					<li><i class="fa fa-heart-o"></i></li>
					<li><div class="heartDecor"></div></li>
				</ul>
			</div>
			<!-- ********************HEART DIVIDER*************** -->
			
			<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore</p>

			

			<div class="galleryNav">
				<div class="galleryNavWrap">
					<nav>
						<ul class="sortNav">
							<li><a href="#option1">All</a></li>
							<li><a href="#option1">Branding</a></li>
							<li><a href="#option1">Web</a></li>
							<li><a href="#option1">Logo Design</a></li>
							<li><a href="#option1">Photography</a></li>
						</ul>
					</nav>
				</div>
			</div>

			<div class="workGallery">
				<div class="workWrap">
					<ul class="workList">
						<li>
							<img src="assets/works_img_1.jpg">
							<div class="hoverBoxWork"></div>
						</li>
						<li><img src="assets/works_img_2.jpg"></li>
						<li><img src="assets/works_img_3.jpg"></li>
						<li><img src="assets/works_img_4.jpg"></li>
						<li><img src="assets/works_img_5.jpg"></li>
						<li><img src="assets/works_img_6.jpg"></li>
						<li><img src="assets/works_img_7.jpg"></li>
						<li><img src="assets/works_img_8.jpg"></li>
					</ul>
				</div>
			</div>
			

		</section> <!-- *******************WORKS SECTION END*************** -->

		<section id="meet">
			<h4 align="center">MEET OUR TEAM</h4>
			<!-- ********************HEART DIVIDER*************** -->
			
			<div class="heartDivider">
				<ul class="heartDeco">
					<li><div class="heartDecor"></div></li>
					<li><i class="fa fa-heart-o"></i></li>
					<li><div class="heartDecor"></div></li>
				</ul>
			</div>
			<!-- ********************HEART DIVIDER*************** -->
			<p class="teamGreeting">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore</p>
			
			<div class="wholeStage">
					<div class="wholeTeamWrap">
						<div class="wholeProfile">			
							<div class="imgBox">
								<div class="hoverBox">
									<div class="label">
										<p class="hoverHeading">Nemo enim ipsam voluptatem quia voluptas</p>
										<p class="hoverBody">sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem.</p>
										<ul class="socialList">
											<li class="socialBox"><i class="fa fa-twitter"></i></li>
											<li class="socialBox"><i class="fa fa-facebook"></i></li>
											<li class="socialBox"><i class="fa fa-google-plus"></i></li>
										</ul>
									</div>	
								</div> <!--hoverBox -->	
								<img src="assets/team_img_1.jpg">
								<div class="infoBox">
									<p class="nameTag">John Filmr Doe</p>
									<p class="jobTag">Managing Director</p>
								</div> <!-- infoBox -->
							</div> <!--imgBox -->
						</div><!-- wholePRofile -->	
						<div class="wholeProfile">			
							<div class="imgBox">
								<div class="hoverBox">
									<div class="label">
										<p class="hoverHeading">Nemo enim ipsam voluptatem quia voluptas</p>
										<p class="hoverBody">sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem.</p>
										<ul class="socialList">
											<li class="socialBox"><i class="fa fa-twitter"></i></li>
											<li class="socialBox"><i class="fa fa-facebook"></i></li>
											<li class="socialBox"><i class="fa fa-google-plus"></i></li>
										</ul>
									</div>	
								</div> <!--hoverBox -->	
								<img src="assets/team_img_2.jpg">
								<div class="infoBox">
									<p class="nameTag">Chystine Hineu</p>
									<p class="jobTag">Lead Designer</p>
								</div> <!-- infoBox -->
							</div> <!--imgBox -->
						</div><!-- wholePRofile -->	
						<div class="wholeProfile">			
							<div class="imgBox">
								<div class="hoverBox">
									<div class="label">
										<p class="hoverHeading">Nemo enim ipsam voluptatem quia voluptas</p>
										<p class="hoverBody">sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem.</p>
										<ul class="socialList">
											<li class="socialBox"><i class="fa fa-twitter"></i></li>
											<li class="socialBox"><i class="fa fa-facebook"></i></li>
											<li class="socialBox"><i class="fa fa-google-plus"></i></li>
										</ul>
									</div>	
								</div> <!--hoverBox -->	
								<img src="assets/team_img_3.jpg">
								<div class="infoBox">
									<p class="nameTag">Martin Matrone</p>
									<p class="jobTag">Lead Developer</p>
								</div> <!-- infoBox -->
							</div> <!--imgBox -->
						</div><!-- wholePRofile -->	
						<div class="wholeProfile">			
							<div class="imgBox">
								<div class="hoverBox">
									<div class="label">
										<p class="hoverHeading">Nemo enim ipsam voluptatem quia voluptas</p>
										<p class="hoverBody">sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem.</p>
										<ul class="socialList">
											<li class="socialBox"><i class="fa fa-twitter"></i></li>
											<li class="socialBox"><i class="fa fa-facebook"></i></li>
											<li class="socialBox"><i class="fa fa-google-plus"></i></li>
										</ul>
									</div>	
								</div> <!--hoverBox -->	
								<img src="assets/team_img_4.jpg">
								<div class="infoBox">
									<p class="nameTag">Steve Flaulkin</p>
									<p class="jobTag">Sr. UI Designer</p>
								</div> <!-- infoBox -->
							</div> <!--imgBox -->
						</div><!-- wholePRofile -->	
					</div> <!-- wholeTeamWrap -->
			</div>  <!-- wholeStage -->
		</section>
		
		<section id="facts">
			<h4 align="center">SOME FUN FACTS</h4>
				<!-- ********************HEART DIVIDER*************** -->
			<div class="heartDivider">
				<ul class="heartDeco">
					<li><div class="heartDecor"></div></li>
					<li><i class="fa fa-heart-o"></i></li>
					<li><div class="heartDecor"></div></li>
				</ul>
			</div>
			<!-- ********************HEART DIVIDER*************** -->
			<ul class="funFacts">
				<li><img src="assets/funfacts_icon_1.png"> <br>
					<p class="number">3200</p>
					<p class"fact">Hours of Work</p></li>
				
				<li><img src="assets/funfacts_icon_2.png"> <br>
					<p class="number">120</p>
					<p class"fact">Satisfied Clients</p></li>
				
				<li><img src="assets/funfacts_icon_3.png"> <br>
					<p class="number">360</p>
					<p class"fact">Projects Delivered</p></li>
				
				<li><img src="assets/funfacts_icon_4.png"> <br>
					<p class="number">42</p>
					<p class"fact">Awards Won</p></li>
			</ul>
		</section>

		<section id="contact">
			<?php include_once("contact.php"); ?>
		</section> 
	
		<?php include_once("footer.php"); ?>  
		
		<script type="text/javascript">
			$(function() {
			    $('.featureSlider').unslider({
			    	dots: true,
			    });
			    	
			});
		</script>
	


</body> 
</html>