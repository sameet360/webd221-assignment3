<!-- FOOTER CONTENT -->

 <footer>
        <img src="assets/map.png">
 
        <div id="bottom">
        	<div class="content">
        		<div id="left">
        			<h1>Brandi</h1> <br>
        			<p>eusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo 
					consequat.</p>
				</div>

				<div id="subscribe">
					<p>Subscribe</p> <br>
					<input type="text" value=">" name="email" id="subsc">
					<p class="small">eusmod tempor incididunt ut labore et dolore 
					magna aliqua.</p>
				</div>

				<div id="explore">
					<p>Explore</p>
					<ul>
						<li><a href="#">Envato</a></li>
						<li><a href="#">Themecurve</a></li>
						<li><a href="#">Kreativeshowcase</a></li>
						<li><a href="#">Freebiescurve</a></li>
						<li><a href="#">Themeforest</a></li>
						<li><a href="#">Microsoft</a></li>
						<li><a href="#">Google</a></li>
						<li><a href="#">Yahoo</a></li>
					</ul>
				</div>	
				
				<div id="copyright">
					<div id="border">
					<p>Created with <i class="fa fa-heart-o"></i> by <a href="#">Themecurve</a>,<br>
						exclusive for kreativeshowcase</p>
					</div>
					<div id="allRights">
						<p><i class="fa fa-copyright"></i> 2014 Brandi. All Rights Reserved.</p>
					</div>
				</div>
			</div>
		</div>
 </footer>
<!-- FOOTER CONTENT -->