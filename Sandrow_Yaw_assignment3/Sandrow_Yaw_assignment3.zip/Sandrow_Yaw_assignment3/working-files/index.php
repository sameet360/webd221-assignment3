<?php include "header.php"; ?>

	<section id="features">
		<div class="container">
			
			<div class="center heart-line">
				<h4 >FEATURES</h4>
				<img src="images/heart-lines.png" alt="">
			</div>
			
				<div class="feature-section">
					<img class="icon" src="images/feather.png" alt="">
					<h5>Branding</h5>
					<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore</p>
				</div>
				<div class="feature-section">
					<img class="icon" src="images/pencil.png" alt="">
					<h5>Development</h5>
					<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore</p>
				</div>
				<div class="feature-section">
					<img class="icon" src="images/speaker.png" alt="">
					<h5>Consulting</h5>
					<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore</p>
				</div>
		</div>
	</section>

	<section class="white-bg">
		<div class="container">
			<div class="center heart-line">
				<h4 >WORKS</h4>
				<img src="images/heart-lines.png" alt="">
			</div>
			<h5 class="center">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam<br> rem aperiam, eaque ipsa quae ab illo inventore</h5>

			<ul id="sub-nav" class="center">
				<a href="" class="boarder-state"><li>All</li></a>
				<a href=""><li>Branding</li></a>
				<a href=""><li>Web</li></a>
				<a href=""><li>Logo Design</li></a>
				<a href=""><li>Photography</li></a>
			</ul>
			
		</div>
		<div id="gallery">

			<div id="effect-6" class="effects clearfix">
            <div class="img">
                <img class="image-container" src="images/work/work_1.jpg" alt="">
                <div class="overlay">
                    <a href="#" class="expand"><i class="fa fa-eye"></i></a>
                    <div class="hover-info">
                    	<h5>Labore et dolore magnam </h5>
                    	<p>Photography</p>
                    </div>

                </div>
            </div>
            <div class="img">
                <img class="image-container" src="images/work/work_2.jpg" alt="">
                <div class="overlay">
                    <a href="#" class="expand"><i class="fa fa-eye"></i></a>
                    <div class="hover-info">
                    	<h5>Labore et dolore magnam </h5>
                    	<p>Photography</p>
                    </div>
                </div>
            </div>
            <div class="img">
                <img class="image-container" src="images/work/work_3.jpg" alt="">
                <div class="overlay">
                    <a href="#" class="expand"><i class="fa fa-eye"></i></a>
                    <div class="hover-info">
                    	<h5>Labore et dolore magnam </h5>
                    	<p>Photography</p>
                    </div>
              
                </div>
            </div>
            <div class="img">
                <img class="image-container" src="images/work/work_4.jpg" alt="">
                <div class="overlay">
                    <a href="#" class="expand"><i class="fa fa-eye"></i></a>
                    <div class="hover-info">
                    	<h5>Labore et dolore magnam </h5>
                    	<p>Photography</p>
                    </div>
                   
                </div>
            </div>
        </div>
		


			<div id="effect-6" class="effects clearfix">
            <div class="img">
                <img class="image-container" src="images/work/work_5.jpg" alt="">
                <div class="overlay">
                    <a href="#" class="expand"><i class="fa fa-eye"></i></a>
                    <div class="hover-info">
                    	<h5>Labore et dolore magnam </h5>
                    	<p>Photography</p>
                    </div>
                   
                </div>
            </div>
            <div class="img">
                <img class="image-container" src="images/work/work_6.jpg" alt="">
                <div class="overlay">
                    <a href="#" class="expand"><i class="fa fa-eye"></i></a>
                    <div class="hover-info">
                    	<h5>Labore et dolore magnam </h5>
                    	<p>Photography</p>
                    </div>
                  
                </div>
            </div>
            <div class="img">
                <img class="image-container" src="images/work/work_7.jpg" alt="">
                <div class="overlay">
                    <a href="#" class="expand"><i class="fa fa-eye"></i></a>
                    <div class="hover-info">
                    	<h5>Labore et dolore magnam </h5>
                    	<p>Photography</p>
                    </div>
                 
                </div>
            </div>
            <div class="img">
                <img class="image-container" src="images/work/work_8.jpg" alt="">
                <div class="overlay">
                    <a href="#" class="expand"><i class="fa fa-eye"></i></a>
                    <div class="hover-info">
                    	<h5>Labore et dolore magnam </h5>
                    	<p>Photography</p>
                    </div>
                
                </div>
            </div>
        </div>
			
		</div>

	</section>

	<section id="meet-team">
		<div class="container">
			<div class="center heart-line">
				<h4 >MEET OUR TEAM</h4>
				<img src="images/heart-lines.png" alt="">
			</div>
			<h5 class="center">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam<br> rem aperiam, eaque ipsa quae ab illo inventore</h5>
			
				<div id="team" >
					<div id="effect-6" class="effects">
						<div class="team-column">
				            <div class="img">
				                <img class="image-container img" src="images/team/team_1.jpg" alt="">
				                <div class="overlay">
				               
				                    <div class="hover-info">
				                    	<h5>Nemo enim ipsam <br> voluptatem quia voluptas </h5>
				                    	<p>sit aspernatur aut odit aut<br> fugit, sed quia consequuntur <br>magni dolores eos qui ratione <br> voluptatem.</p>
				                    	<div class="social-media-holder">
					                    	<i class="fa fa-twitter"></i>
					                    	<i class="fa fa-facebook"></i>
					                    	<i class="fa fa-google-plus"></i>
					                    </div>
				                    </div>
				                </div>
				                </div>
				                <h3>John Filmr Doe
				                	<p class="team-mate-names">Managing Director</p>
				                </h3>
								
				            </div>
				             <div class="team-column">      
				            <div class="img">
				                <img class="image-container img" src="images/team/team_2.jpg" alt="">
				                <div class="overlay">
				                    
				                     <div class="hover-info">
				                    	<h5>Nemo enim ipsam <br> voluptatem quia voluptas </h5>
				                    	<p>sit aspernatur aut odit aut<br> fugit, sed quia consequuntur <br>magni dolores eos qui ratione <br> voluptatem.</p>
				                    	<div class="social-media-holder">
					                    	<i class="fa fa-twitter"></i>
					                    	<i class="fa fa-facebook"></i>
					                    	<i class="fa fa-google-plus"></i>
					                    </div>
				                    </div>
				                  
				                </div>
				                </div>
								<h3>Chystine Hineu
									<p class="team-mate-names">Lead Designer</p>
								</h3>
								
				            </div>
							<div class="team-column">
					            <div class="img">
					                <img class="image-container img" src="images/team/team_3.jpg" alt="">
					                <div class="overlay">
					                    
					                     <div class="hover-info">
					                    	<h5>Nemo enim ipsam <br> voluptatem quia voluptas </h5>
					                    	<p>sit aspernatur aut odit aut<br> fugit, sed quia consequuntur <br>magni dolores eos qui ratione <br> voluptatem.</p>
					                    	<div class="social-media-holder">
						                    	<i class="fa fa-twitter"></i>
						                    	<i class="fa fa-facebook"></i>
						                    	<i class="fa fa-google-plus"></i>
						                    </div>
					                   	</div>
					                 
					                </div>
					                </div>
								<h3>Martin Matrone
									<p class="team-mate-names">Lead Developer</p>
								</h3>
								
				            </div>
				            <div class="team-column">
					            <div class="img">
					                <img class="image-container img" src="images/team/team_4.jpg" alt="">
					                <div class="overlay">
					                    
					                     <div class="hover-info">
					                    	<h5>Nemo enim ipsam <br> voluptatem quia voluptas </h5>
					                    	<p>sit aspernatur aut odit aut<br> fugit, sed quia consequuntur <br>magni dolores eos qui ratione <br> voluptatem.</p>
					                    	<div class="social-media-holder">
						                    	<i class="fa fa-twitter"></i>
						                    	<i class="fa fa-facebook"></i>
						                    	<i class="fa fa-google-plus"></i>
						                    </div>
					                    </div>
					                
					                </div>
					                </div>
								<h3>Steve Flaulkin
									<p class="team-mate-names">Sr. UI Designer</p>
								</h3>
							
				            </div>
				            <div id="scroller">
						            <i class="fa fa-circle"></i>
						            <i class="fa fa-circle-o"></i>
						            <i class="fa fa-circle-o"></i>
					            </div>

			        </div>
				</div>


		</div>
	</section>

	<section id="fun-facts">
		<div class="container">
			
			<div class="center heart-line">
				<h4 >SOME FUN FACTS</h4>
				<img src="images/heart-lines(wht).png" alt="">
			</div>
				<ul>
					<li> <img src="images/some-fun-facts/clock.png" alt=""> <h5>3200</h5> <p>Hours of Work</p> </li>
					<li><img src="images/some-fun-facts/friends.png" alt=""> <h5>120</h5> <p>Satisfied Clinets</p></li>
					<li><img src="images/some-fun-facts/rockets.png" alt=""> <h5>360</h5> <p>Projects delivered</p></li>
					<li><img src="images/some-fun-facts/cup.png" alt=""> <h5>42</h5> <p>Awards Won</p></li>
				</ul>
		</div>
	</section>

	<section id="let-discuss">
		<div class="container">
			
			<div class="center heart-line">
				<h4 >Let’s Discuss</h4>
				<img src="images/heart-lines.png" alt="">
			</div>

			<h5 class="center">Voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore</h5>

			<article>
				<div class="address">
					<h3>Cras at ultrices erat, sed vul- <br>putate!</h3>
					<p>
						2345 Setwant natrer, 1234, <br> Washington. United States. <br> (401) 1234 567 <br> hello@brandi.com <br> www.brandi.com
					</p>
				</div>
				<form>
					<h4>Say hello!</h4>
					<input class="form-text" type="text" name="Name" placeholder="Name">
					<input class="form-text" type="text" name="Email" placeholder="Email">
					<input id="message-form" class="form-text" type="text" name="Message" placeholder="Message">

				<div id="send-message"><h3><i class="fa fa-envelope-o"></i> Send message</h3></div>

				</form>
				<aside>
					<i class="fa fa-behance"></i>
					<i class="fa fa-twitter"></i>
					<i class="fa fa-dribbble"></i>
					<img src="images/forrst.png">
					<i class="fa fa-google-plus"></i>
					<i class="fa fa-facebook-square"></i>

				</aside>

			</article>

		</div>
		
		
	</section>
	<img id="map" src="images/map.png" alt="">

	<?php include "footer.php"; ?>
