<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Brandi</title>
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link href='http://fonts.googleapis.com/css?family=Pacifico' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,300,700,600,800,400' rel='stylesheet' type='text/css'>

    <link rel="stylesheet" href="css/font-awesome.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">


<script src="js/jquery-1.9.1.min.js"></script>
<script src="js/modernizr.js"></script>
<script>
    $(document).ready(function(){
        if (Modernizr.touch) {
            // show the close overlay button
            $(".close-overlay").removeClass("hidden");
            // handle the adding of hover class when clicked
            $(".img").click(function(e){
                if (!$(this).hasClass("hover")) {
                    $(this).addClass("hover");
                }
            });
            // handle the closing of the overlay
            $(".close-overlay").click(function(e){
                e.preventDefault();
                e.stopPropagation();
                if ($(this).closest(".img").hasClass("hover")) {
                    $(this).closest(".img").removeClass("hover");
                }
            });
        } else {
            // handle the mouseenter functionality
            $(".img").mouseenter(function(){
                $(this).addClass("hover");
            })
            // handle the mouseleave functionality
            .mouseleave(function(){
                $(this).removeClass("hover");
            });
        }
    });

    $(document).ready(function(){
    
    $("#hit").click(function() {
        $(".navigation").slideToggle();
    });
    });
</script>

</head>
<body>
 <header>
        <nav>
            <div class="container">
                <h1> </h1>

                <div class="tagline">
                    <p>I'am your tag line</p> 
                </div>
                <span><i id="hit" class="fa fa-bars"></i></span>
                <ul class="navigation ">
                    <li>Home</li>
                    <li>Features</li>
                    <li>Works</li>
                    <li>Team</li>
                    <li>Contact</li>
                </ul>    
            </div>
        </nav>
        <ul id="dot-holder">
            <li id="dots-fill"></li>
                <li class="dots"></li>
                <li class="dots"></li>
            </ul>
        <div class="center">
                

                <h2 class=".h2">Meet <span class="bold">Brandi</span>! </h2>
                <h3> <span class="green_color">/creative</span>  one page template. </h3>

                <p> <span class="green_color"> &#8212&#8212 </span> &nbsp; &nbsp; &nbsp; &nbsp; We are a team of professionals &nbsp; &nbsp; &nbsp; &nbsp;<span class="green_color"> &#8212&#8212 </span></p>
                <ul id="socialMedia">
                    <li><i class="fa fa-twitter"></i></li>
                    <li><i class="fa fa-facebook"></i></li>
                    <li><i class="fa fa-google-plus"></i></li>
                    <li><i class="fa fa-dribbble"></i></li> 
                </ul>
        </div>
 </header>
