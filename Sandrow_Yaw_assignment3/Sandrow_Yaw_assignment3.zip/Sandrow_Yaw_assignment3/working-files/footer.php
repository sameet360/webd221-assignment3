	<footer>
			<div class="container">
				<div class="foot-container">
					<div class="footer-titels">
						<h1> </h1>
						<p>eusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
					</div>

					<div class="footer-titels">
						<h2>Subscribe </h2>
						<form action="">
						<input type="text">
							<!-- <i class="fa fa-angle-right"></i> -->
						</input>
						</form>
						<p>
							eusmod tempor incididunt ut labore et dolore magna aliqua. 
						</p>
					</div>

					<div id="explore" class="footer-titels">
						<h2>Explore</h2>
						<ul>
							<li>Envato</li>
							<li>Themecurve</li>
							<li>Kreativeshowcase</li>
							<li>Freebiescurve</li>
						</ul>

						<ul>
							<li>Themeforest</li>
							<li>Microsoft</li>
							<li>Google</li>
							<li>Yahoo</li>
						</ul>

						
					</div>

					<div id="created-by" class="footer-titels">
						<p>Created with <i class="fa fa-heart-o"></i>by <span>themecurve</span>,<br> exclusive for kreativeshowcase</p>
						<span id="copy-right">© 2014 Brandi. All Rights Reserved.</span>
					</div>
				</div>
			</div>
			
		</footer>
	
</body>
</html>